from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model.stochastic_gradient import SGDClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import VotingClassifier
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import MultinomialNB

from sentiment_analysis import create_feature_set_and_labels
from tfidf_vectorizer import get_features

train_x, train_y, test_x, test_y = create_feature_set_and_labels('pos_final.txt', 'neg_final.txt')
#train_x, train_y, test_x, test_y = get_features()

#print(train_x[0], train_y[0])
x = train_x + test_x
y = train_y + test_y

clf1 = LinearRegression()
clf2 = LogisticRegression()
clf3 = SGDClassifier()
clf4 = SVC()
clf5 = KNeighborsClassifier()
clf6 = MLPClassifier()
clf7 = DecisionTreeClassifier()
clf8 = MultinomialNB()
clf1.fit(train_x, train_y)
y_pred = clf1.predict(test_x)
print("LinearRegressionAccuracy   ", accuracy_score(test_y, y_pred.round()))
eclf = VotingClassifier(
    estimators=[('logr', clf2), ('sgd', clf3), ('svm', clf4), ('kn', clf5), ('nn', clf6), ('dt', clf7)], voting='hard')

for label, clf in zip(
        ['LogisticRegressionClassifier', 'SGDClassifierClassifier', 'SVCClassifier',
         'NearestNeighbourClassifier', 'NeuralNetworkClassifier', 'DecisionTreeClassifier', 'MultinomialNB' ,'EnsembleClassifier'],
        [clf2, clf3, clf4, clf5, clf6, clf7, clf8, eclf]):
    scores = cross_val_score(clf, x, y, cv=10, scoring='accuracy')
    f_measure = cross_val_score(clf,x,y,cv=10, scoring = 'f1')
    #print(scores)
    print(label, "Accuracy:  ", scores.mean(), "+/- ", scores.std())
    print (label,"F-measure:  ", f_measure.mean())
